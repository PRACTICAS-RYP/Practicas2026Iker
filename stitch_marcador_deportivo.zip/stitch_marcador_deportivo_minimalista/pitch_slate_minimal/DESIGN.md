---
name: Pitch Slate Minimal
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#e6bdb8'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#ac8884'
  outline-variant: '#5c403c'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690005'
  primary-container: '#dc2626'
  on-primary-container: '#fff6f5'
  inverse-primary: '#bf0715'
  secondary: '#b4c5ff'
  on-secondary: '#002a78'
  secondary-container: '#0053db'
  on-secondary-container: '#cdd7ff'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#008259'
  on-tertiary-container: '#e1ffec'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-score-desktop:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.04em
  display-score-mobile:
    fontFamily: Space Grotesk
    fontSize: 52px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.04em
  clock-display:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-numeric:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies precision athletic telemetry: high-intensity focus stripped of ornamental noise. It positions the mobile scoreboard not merely as an informational table, but as a digital stadium console built for rapid, glanceable clarity during live matches.

The visual style is **Tactical High-Contrast Minimalism**. It pairs near-black pitch slate canvases with vibrant, high-luma primary and secondary team accents. Content hierarchy is driven strictly by massive tabular metrics, structured mono/condensed numeric forms, and disciplined spacing. The emotional response is immediate, kinetic, and objective: delivering the authoritative presence of a live stadium LED display re-engineered into an ultra-refined mobile interface.

## Colors

The palette leverages a deep athletic night spectrum. Pure chromatic signals denote team identity and match states, anchored by an ink-slate core.

- **Primary Accent (`#DC2626` / Local):** High-energy, deep vibrant crimson reserved for local team telemetry, active alerts, stoppage-time indicators, and local possession states.
- **Secondary Accent (`#2563EB` / Away):** Electric cerulean engineered for visitor identity, away stat bars, and neutral counter-elements.
- **Tertiary Accent (`#10B981` / Live State):** Crisp pitch emerald reserved strictly for active running clocks, live status pills ("LIVE", "EXTRA TIME"), and verified positive metrics.
- **Neutral Canvas (`#0F172A` / Stadium Slate):**
  - Surface Root: `#0F172A` (deep dark slate canvas)
  - Surface Card / Tier 1: `#1E293B` (elevated panel)
  - Surface Inset / Track: `#111827` (sub-tier background for progress bars and metric wells)
  - Ghost Border: `rgba(255, 255, 255, 0.08)` for razor-thin structural containment
  - Text High-Emphasis: `#F8FAFC` (pure optic off-white)
  - Text Medium-Emphasis: `#94A3B8` (cool metallic gray)
  - Text Low-Emphasis / Inactive: `#475569` (muted slate)

## Typography

The typographic hierarchy divides utility into two specialized roles:

1. **Telemetry & Numerics (`Space Grotesk`):** Applied to scores, match clocks, foul tallies, and section micro-caps. It provides mechanical, geometric certainty with strict tabular spacing (`font-variant-numeric: tabular-nums`) to avoid UI jitter during live score or clock updates.
2. **Body & Metadata (`Manrope`):** Applied to team names, player rosters, event logs, and match detail captions. Its clean geometric sans-serif traits provide maximum legibility at small sizes against dark slate backdrops.

All scores, periods, and timestamps must always use `tabular-nums` and bold weights (`600` or `700`) to mirror stadium board fidelity.

## Layout & Spacing

The layout is built for instantaneous single-hand thumb navigation on mobile devices, utilizing a structured fluid 4-column layout on mobile, scaling to 8 columns on tablets.

- **Grid Strategy:** Fluid, column-based layout with a dense vertical rhythm driven by `space-sm` (8px) base increments.
- **Safe Margins:** A fixed `1rem` (16px) margin preserves outer perimeter touch targets and aligns screen gutters with bezel edges.
- **Section Stack Rhythm:** Scoreboards pin to the top safe area. Modular statistic split-cards stack vertically with consistent `space-md` gaps.
- **Horizontal Balance:** Split stat comparisons (Possession, Shots on Target, Corner Kicks) distribute symmetrically from a razor center-axis, using `space-xs` and `space-sm` between comparative indicator bars.

## Elevation & Depth

This design system rejects fuzzy multi-colored skeuomorphic drop shadows in favor of **Crisp Low-Contrast Outlines & Tonal Grounding**:

- **Layer 0 (Canvas Base):** Deep stadium slate `#0F172A`.
- **Layer 1 (Modular Stadium Cards):** Elevated slate `#1E293B` bordered by a crisp `1px` stroke of `rgba(255, 255, 255, 0.08)`. Never apply soft blurry drop shadows to primary scoreboard cards.
- **Layer 2 (Stat Wells & Inset Tracks):** Recessed surfaces (`#111827`) set inside cards for progress meters and comparative breakdown tracks.
- **Interactive State Elevation:** Active interactive elements (such as timeline scrubbers or team filter toggles) take an ultra-fine `1px` border of `rgba(255, 255, 255, 0.2)` with a subtle micro-glow matching the corresponding team accent (`0 0 12px rgba(220, 38, 38, 0.25)` for Local; `0 0 12px rgba(37, 99, 235, 0.25)` for Away).

## Shapes

The geometric architecture relies on **Soft / Semi-Sharp Geometry** (Roundedness scale `1`):

- **Cards & Data Modules:** `4px` (`0.25rem`) corner radius. This conveys a mechanical, tactical digital board feel, avoiding oversized or toy-like roundness.
- **Status Pills & Live Chips:** `4px` radius for structural tags, or full capsules (`9999px`) strictly limited to the dynamic pulsing "LIVE" game indicator and local/away possession badges.
- **Telemetry Bars:** Segmented or flat square-edged bars (`2px` radius) to maximize comparative data legibility in small spaces.

## Components

### 1. Main Scoreboard Header Module
- **Structure:** Monolithic card positioned at screen top. Features Local team on the left, Away team on the right, and the match status/clock in the center column.
- **Scores:** Displayed using `display-score-mobile` in pure white (`#F8FAFC`).
- **Team Identification:** Local abbreviated tag paired with a solid 3px vertical crimson accent bar (`#DC2626`); Away paired with a solid 3px electric blue accent bar (`#2563EB`).
- **Match Clock:** Displayed in `clock-display` Space Grotesk above the active half/period tag. Active live minutes utilize tertiary green `#10B981` accompanied by a 6px pulsating live dot.

### 2. Comparative Telemetry Cards (Stats)
- **Structure:** Clean slate cards (`#1E293B`) with 1px `rgba(255, 255, 255, 0.08)` borders.
- **Layout:** Metric label (e.g., "POSSESSION", "SHOTS ON TARGET", "FOULS") in `label-caps` centered in muted gray (`#94A3B8`).
- **Data Bars:** Dual opposing bar tracks. Left side fills with `#DC2626` (Local), right side fills with `#2563EB` (Away). Numerical metrics anchor the exterior edges in `label-numeric`.

### 3. Action Chips & Filter Toggles
- **Default State:** Inset slate `#111827` with crisp hairline outline `rgba(255, 255, 255, 0.1)`. Text in `#94A3B8`.
- **Active State:** High-contrast solid white `#F8FAFC` background with ink text `#0F172A` for global views, or filled with corresponding team accent color for team-filtered game feeds.

### 4. Live Event Timeline / Feed List
- **List Items:** Separated by 1px horizontal rule `rgba(255, 255, 255, 0.05)`.
- **Event Stamps:** Minute badge in `label-numeric` set in a rectangular chip (`#111827`).
- **Accented Event Markers:** Yellow/Red card icons, goal markers, or substitutions display an inset indicator matching the responsible team's color token.

### 5. Buttons & Interactive Controls
- **Primary Action:** Solid crimson (`#DC2626`) or electric blue (`#2563EB`) depending on context; default utility actions use white `#F8FAFC` fill with `#0F172A` text.
- **Ghost/Tertiary Action:** Border `1px solid rgba(255, 255, 255, 0.15)`, transparent background, hover/pressed state `rgba(255, 255, 255, 0.05)`.
---
name: MIT-DIBA Public Intelligence
colors:
  surface: '#f3faff'
  surface-dim: '#c9dde7'
  surface-bright: '#f3faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e6f6ff'
  surface-container: '#ddf1fc'
  surface-container-high: '#d8ebf6'
  surface-container-highest: '#d2e6f0'
  on-surface: '#0b1e25'
  on-surface-variant: '#41484b'
  inverse-surface: '#21333b'
  inverse-on-surface: '#e0f4fe'
  outline: '#71787b'
  outline-variant: '#c1c7cb'
  surface-tint: '#3e6472'
  primary: '#002934'
  on-primary: '#ffffff'
  primary-container: '#163f4c'
  on-primary-container: '#83aab9'
  inverse-primary: '#a5cddd'
  secondary: '#b32444'
  on-secondary: '#ffffff'
  secondary-container: '#fe5e78'
  on-secondary-container: '#64001d'
  tertiary: '#252520'
  on-tertiary: '#ffffff'
  tertiary-container: '#3b3a35'
  on-tertiary-container: '#a6a49c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1e9f9'
  primary-fixed-dim: '#a5cddd'
  on-primary-fixed: '#001f28'
  on-primary-fixed-variant: '#254c59'
  secondary-fixed: '#ffdadc'
  secondary-fixed-dim: '#ffb2b9'
  on-secondary-fixed: '#400010'
  on-secondary-fixed-variant: '#91012f'
  tertiary-fixed: '#e6e2da'
  tertiary-fixed-dim: '#cac6bf'
  on-tertiary-fixed: '#1c1c17'
  on-tertiary-fixed-variant: '#484741'
  background: '#f3faff'
  on-background: '#0b1e25'
  surface-variant: '#d2e6f0'
typography:
  headline-hero:
    fontFamily: Merriweather
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  headline-hero-mobile:
    fontFamily: Merriweather
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: Merriweather
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Merriweather
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  metric-display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system serves public administration professionals, municipal technicians, and regional planners navigating the intelligence ecosystem of tourism across the province of Barcelona. The personality balances institutional rigor, civic responsibility, and analytical clarity.

Drawing inspiration from contemporary editorial design and civic tech minimalism, the visual tone avoids commercial saturation in favor of a warm, paper-inspired foundational palette (ivory, stone, slate) reinforced by authoritative petroleum blue and institutional garnet accents. It projects trust, methodical governance, and long-term sustainability, ensuring data-dense diagnostic interfaces feel welcoming, transparent, and effortlessly navigable.

## Colors
The system is anchored in high-legibility light mode, engineered to meet strict WCAG 2.1 AA accessibility ratios against subtle warm-tone backdrops.

### Structural & Core Palette
- **Petroleum Blue (Structural / Primary)** `#163F4C`: Used for primary global navigation chrome, data visualizations, primary metric titles, and high-emphasis focal elements.
- **Institutional Garnet (Accent / Secondary)** `#A6193C`: Reserved for active states, key branding marks, callouts, and decisive user actions.
- **Base Canvas (Ivory)** `#F7F4EE`: Main background surface providing warm, low-glare reading conditions.
- **Card & Elevated Canvas (Secondary Ivory)** `#EEEAE2`: Distinguishes utility modules, sub-panels, and secondary groupings.
- **Primary Text** `#20323A`: High-contrast slate charcoal for dense analytical copy, numbers, and navigation labels.
- **Secondary Text** `#65747A`: Muted slate for metadata, captions, timestamps, and secondary table columns.
- **Borders & Dividers**: Primary rule `#D8D2C5`, subtle panel outline `#E2DDD4`.

### Strategic Model Axes (The 5 Dimensions)
Categorical tokens are reserved exclusively for the five strategic pillars across charts, badges, and progress indicators:
- **Gobernanza**: `#A92C48`
- **Sostenibilidad**: `#608460`
- **Accesibilidad**: `#C59638`
- **Innovación**: `#397C9D`
- **Tecnología**: `#696087`

## Typography
The system balances institutional gravitas with digital productivity.

- **Merriweather** is employed exclusively for top-level greetings, territorial summaries, and major executive reports. It communicates formal governance and credibility without feeling archaic.
- **Inter** handles all functional interface areas: KPIs, tables, filters, forms, tooltips, chart legends, and navigation headers. Its neutral geometry and open counters ensure legibility even at dense 11px and 12px scales.
- When rendering numeric dashboard readouts, `font-feature-settings: 'tnum'` (tabular figures) is mandatory to ensure aligned columns across comparison rows.

## Layout & Spacing
A 12-column responsive fluid grid structured inside a maximum content width of 1440px provides breathing room while preventing extreme horizontal eye travel on ultra-wide displays.

- **Desktop (1200px+)**: 12 columns, 24px (`1.5rem`) gutters, 40px (`2.5rem`) lateral margins.
- **Tablet (768px – 1199px)**: 8 columns, 16px (`1rem`) gutters, 24px (`1.5rem`) lateral margins.
- **Mobile (below 768px)**: 4 columns, 16px gutters, 16px lateral margins. KPI stat rows collapse into a 2x2 grid or a stacked carousel.

Vertical rhythm relies strictly on the 8px baseline scale. Card interiors maintain `space-lg` (24px) padding for standard metrics and `space-md` (16px) for compact analytical modules.

## Elevation & Depth
In alignment with public sector clarity and accessibility, depth is conveyed through flat tonal surface layering and crisp structural outlines rather than heavy skeuomorphic drop shadows.

- **Level 0 (Base Surface)**: `#F7F4EE` flat canvas.
- **Level 1 (Card & Module Layer)**: Pure white `#FFFFFF` or secondary tint `#EEEAE2`, bounded by a hairline stroke of `1px solid #E2DDD4`. Shadows are nearly imperceptible: `0 1px 3px rgba(32, 50, 58, 0.04)`.
- **Level 2 (Interactive Floating / Menus / Tooltips)**: White `#FFFFFF` with `1px solid #D8D2C5` border and soft ambient shadow: `0 4px 12px rgba(22, 63, 76, 0.08)`.
- **Level 3 (Modals & Drawers)**: Surface `#FFFFFF`, border-free, supported by a 40% translucent backdrop `#163F4C66` and a structured shadow: `0 16px 32px rgba(22, 63, 76, 0.16)`.

## Shapes
Shapes are controlled and geometric, conveying precision and public institutional dignity:

- Base inputs, buttons, chips, and small alert banners utilize soft corners (4px, `rounded-sm` to `rounded-md`).
- Metric dashboard containers, diagnostic cards, and modal dialogs adopt 8px (`rounded-lg`) corner radii to soften information clusters without appearing casual or toy-like.
- Strategic step indicators and user profile badges utilize perfect circular geometries (`rounded-full`) to differentiate process flow nodes and avatars from data cards.

## Components

### Double Institutional Header
- **Top Utility Tier (Height: 64px)**: Background `#FFFFFF`, bottom border `1px solid #E2DDD4`. Houses the MIT-DIBA institutional logo alongside the official Diputació de Barcelona shield. Right-aligned territorial language picker (CA | ES) and global portal links.
- **Bottom Navigation Tier (Height: 52px)**: Background `#163F4C`. Primary horizontal links (Inicio, Destinos, Diagnósticos, Indicadores, Resultados, Informes) rendered in white with muted 80% opacity. The active item takes a solid background of `#A6193C` with full white text. Contains the embedded search bar and compact user profile capsule.

### Action Buttons
- **Primary**: Solid `#A6193C` background, white text, 4px corner radius, font weight 600. Hover state darkens to `#8B1532`.
- **Secondary / Structural**: Solid `#163F4C` with white text. Hover transitions to `#1E4F5E`.
- **Outline / Administrative**: Transparent background, `1px solid #D8D2C5`, text `#20323A`. Hover background shifts to `#EEEAE2`.

### KPI Metric Cards
- White `#FFFFFF` background, 8px radius, `1px solid #E2DDD4` border.
- Layout: Top row displays the categorical icon container (40x40px rounded-full with 10% opacity axis tint) alongside the numerical metric (`36px` Inter bold). Right column displays the percentage delta badge (green `#2E7D32` for positive, red `#C62828` for negative).
- Bottom row provides the metric label in `#20323A` with secondary comparison text in `#65747A`.

### Diagnostic Axis Badges & Chips
- Soft pill or rounded-md tags combining a 10% tinted background of the corresponding axis color with a bold 100% hue label and matching 16px icon.
- Used in audit lists, diagnostic tables, and radar breakdown views.

### Tables & Data Grids
- Header row: Background `#EEEAE2`, text `#20323A` in 12px uppercase semibold with subtle `1px solid #D8D2C5` bottom divider.
- Data rows: Alternating or white surfaces with hover fill `#F7F4EE`. Numbers rendered in tabular lining figures.

### Process Flow Tracker (El flujo del proceso)
- Horizontal stepper container `#EEEAE2` with circular indicator nodes (48px) matching the phase status (diagnostic, verification, results, reports).
- Active nodes utilize accent colors with directional arrow separators `#D8D2C5`.